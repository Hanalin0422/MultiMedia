#include <stdio.h>
#include <dshow.h>

char g_fileName[256];
char g_PathFileName[512];

BOOL GetMediaFileName();
HRESULT SaveGraphFile(IGraphBuilder*, WCHAR*);
IPin *GetUnconnectedPin(IBaseFilter*, PIN_DIRECTION);

int main(int argc, char* argv[])
{
	IGraphBuilder *pGraph = NULL;
	IMediaControl *pControl = NULL;
	IMediaEvent *pEvent = NULL;
	IBaseFilter *pInputFileFilter = NULL;
	IBaseFilter *pDSoundRenderer = NULL;
	IPin *pFileOut = NULL, *pWAVIn = NULL;

	if (!GetMediaFileName()){
		return(0);
	}

	HRESULT hr = CoInitialize(NULL);
	if (FAILED(hr))
	{
		printf("ERROR - Could not initialize COM library");
		return hr;
	}

	hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void **)&pGraph);

	if (FAILED(hr))
	{
		printf("ERROR - Could not create the Filter Graph Manager.");
		CoUninitialize();
		return hr;
	}

	hr = pGraph->QueryInterface(IID_IMediaControl, (void **)&pControl);
	if (FAILED(hr))
	{
		pGraph->Release();
		CoUninitialize();
		return hr;
	}

	hr = pGraph->QueryInterface(IID_IMediaEvent, (void **)&pEvent);
	if (FAILED(hr))
	{
		pControl->Release();
		pGraph->Release();
		CoUninitialize();
		return hr;
	}

#ifndef UNICODE
	WCHAR wFileName[MAX_PATH];
	MultiByteToWideChar(CP_ACP, 0, g_PathFileName, -1, wFileName, MAX_PATH);
	hr = pGraph->AddSourceFilter(wFileName, wFileName, &pInputFileFilter);
#else
	hr = pGraph->AddSourceFilter(wFileName, wFileName, &pInputFileFilter);
#endif
	if (SUCCEEDED(hr)){
		hr = CoCreateInstance(CLSID_DSoundRender, NULL, CLSCTX_INPROC_SERVER, IID_IBaseFilter, (void **)&pDSoundRenderer);

		if (SUCCEEDED(hr)){
			hr = pGraph->AddFilter(pDSoundRenderer, L"Audio Renderer");
			if (SUCCEEDED(hr)){
				pFileOut = GetUnconnectedPin(pInputFileFilter, PINDIR_OUTPUT);

				if (pFileOut != NULL){
					pWAVIn = GetUnconnectedPin(pDSoundRenderer, PINDIR_INPUT);

					if (pWAVIn != NULL){
						hr = pGraph->Connect(pFileOut, pWAVIn);
					}
				}
			}
		}
	}

	if (SUCCEEDED(hr))
	{
		printf("Befinning to play media file ... \n");
		hr = pControl->Run();

		if (SUCCEEDED(hr))
		{
			long evCode;
			pEvent->WaitForCompletion(INFINITE, &evCode);
		}
		hr = pControl->Stop();
	}

	SaveGraphFile(pGraph, L"C:\\Users\\user\\Desktop\\passat.mpg");

	if (pFileOut){
		pFileOut->Release();
	}
	if (pWAVIn){
		pWAVIn->Release();
	}
	if (pInputFileFilter){
		pInputFileFilter->Release();
	}
	if (pDSoundRenderer){
		pDSoundRenderer->Release();
	}
	pControl->Release();
	pEvent->Release();
	pGraph->Release();
	CoUninitialize();

	return 0;
}

HRESULT GetUnconnectedPin(
	IBaseFilter *pFilter,
	PIN_DIRECTION PinDir,
	IPin **ppPin
	)
{
	IEnumPins *pEnum = 0;
	IPin *pPin = 0;

	if (!ppPin) return E_POINTER;
	*ppPin = 0;

	HRESULT hr = pFilter->EnumPins(&pEnum);
	if (FAILED(hr)) return hr;

	while (pEnum->Next(1, &pPin, NULL) == S_OK)
	{
		PIN_DIRECTION ThisPinDir;

		pPin->QueryDirection(&ThisPinDir);
		if (ThisPinDir == PinDir){
			IPin *pTmp = 0;

			hr = pPin->ConnectedTo(&pTmp);
			if (SUCCEEDED(hr)){
				pTmp->Release();
			}
			else{
				pEnum->Release();
				*ppPin = pPin;
				return S_OK;
			}
		}
		pPin->Release();
	}
	pEnum->Release();
	return E_FAIL;
}